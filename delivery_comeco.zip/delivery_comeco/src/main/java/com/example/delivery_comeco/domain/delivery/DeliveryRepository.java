package com.example.delivery_comeco.domain.delivery;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryRepository extends JpaRepository <Delivery, String>{}

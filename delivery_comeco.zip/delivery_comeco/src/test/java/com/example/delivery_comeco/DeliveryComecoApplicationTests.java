package com.example.delivery_comeco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryComecoApplicationTests {

	@Test
	void contextLoads() {
	}

}
